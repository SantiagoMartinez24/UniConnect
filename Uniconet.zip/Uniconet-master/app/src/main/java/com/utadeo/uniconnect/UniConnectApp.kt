
package com.utadeo.uniconnect

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class UniConnectApp : Application()
